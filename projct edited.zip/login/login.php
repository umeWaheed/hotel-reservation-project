
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="../../bootstrap-3.3.7-dist/css/bootstrap.css">

    <link rel="stylesheet" href="log.css">
    <link rel="stylesheet" href="../navbar.css">
</head>

<div class="menu">
    <a href="../home%20page/page1.html" class="navbar-brand"><img src="../images/logo.png" alt="logo"></a>
    <nav class="navbar">
        <ul class="nav navbar-nav">
            <li><a href="../home%20page/page1.html">Home</a></li>
            <li class="active"><a href="../hotel/hotel.html">Hotels</a></li>
            <li><a href="../location/location.html">Discover</a></li>
            <li><a href="../guides/guides.html">Guides</a></li>
            <li><a href="../gallery/gallery.html">Gallery</a></li>
            <li><a href="../special%20occasions/page3.html">Special events</a></li>
        </ul>
    </nav>
</div>

<?php
include ('../projectdb.php');
session_start();
$error="";
if(isset($_POST['submit'])){
	if(empty($_POST['email']) || empty($_POST['password'])) {
		$error="email or password is invalid";
	
	}
	else {
		$username=$_POST['email'];
		$password=$_POST['password'];
		$query = mysqli_query($conn,"select * from signup where Password='$password' AND Email='$username'");
		$rows = mysqli_num_rows($query);
		if($query){
			?>
			<h2>Success</h2>
			<?php
			$SESSION['login_user']=$username;
		}else {
			
		}
		mysqli_close($conn);
	}
}?>
<div class="col-md-4 form">
    <form action="login.php" method="post">
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="example@example.com" class="form-control">

        <label for="pass">Password</label>
        <input type="password" id="pass" name="password" placeholder="password" class="form-control">
      <input type="submit" name="submit" value="Login" class="btn btn-primary" onclick="location.href='../hotel/hotel.php'">
	<span><?php echo $error; ?></span>
    <p>Don't have a account? <a href="../signup/signup.html">Sign up</a></p>
	</form>
</div>

<div class="col-md-6 quote">
    <p>
        “Traveling – it leaves you speechless, then turns you into a storyteller.” <br>– Ibn Battuta
    </p>
</div>
</body>
</html>